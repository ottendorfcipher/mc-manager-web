Place your .ogg audio files here.
Example: my_song.ogg  →  matches "name": "redstonecipher/music/my_song" in sounds.json
