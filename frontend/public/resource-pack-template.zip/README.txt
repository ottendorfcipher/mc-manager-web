redstoneCipher Custom Music — Starter Template
================================================

HOW TO ADD CUSTOM MUSIC
-----------------------

1. CONVERT your audio files to OGG Vorbis format (.ogg).
   ffmpeg:  ffmpeg -i song.mp3 -c:a libvorbis my_song.ogg
   Audacity: File → Export → Export as OGG

2. PLACE each .ogg file inside the zip at:
     assets/redstonecipher/sounds/music/<filename>.ogg

3. REGISTER it in assets/redstonecipher/sounds.json.
   Copy the pattern already in that file:

     "music.my_song": {
       "sounds": [{ "name": "redstonecipher/music/my_song", "stream": true }]
     }

   • The key ("music.my_song") is the event name.
   • "name" is the path to the .ogg file under assets/redstonecipher/sounds/
     WITHOUT the .ogg extension and with / as separator.
   • Always set "stream": true for music (avoids memory issues on long tracks).

4. UPLOAD the zip in the redstoneCipher dashboard → Music → Custom Music.

5. REGISTER each track in the dashboard form:
     Sound ID     →  redstonecipher:music.my_song
                      ─────────────  ────────────
                      folder name    key in sounds.json
     Track Name   →  My Song
     Artist       →  Artist Name
     Duration     →  3:45  (how long the track actually plays)

SOUND ID FORMAT
---------------
  namespace:event.name
  e.g.  redstonecipher:music.my_song
        ─────────────  ──────────────
        = "redstonecipher" folder     = key in sounds.json
        under assets/

NOTES
-----
• Audio MUST be OGG Vorbis — other formats will be silently ignored by Minecraft.
• pack_format 22 targets Minecraft 1.20.3+.  supported_formats covers 1.20–1.21.x.
• The zip root must contain pack.mcmeta directly (not inside a subfolder).
• Players download the pack automatically when they (re)join the server.
